// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_TEST_REPORTER_H
#define __LIT_TEST_TEST_REPORTER_H

#include "litTestReporter.h"
#include <vector>
#include <map>

namespace lit {
namespace testing {

    /*! @brief TestReporter that generates the output on std::cout
     * @ingroup Testing*/
    class TestTestReporter : public TestReporter
    {
    public:
      TestTestReporter();
      virtual ~TestTestReporter();

      virtual void reportComment(const StringType& comment);
      virtual void reportTestStart(const LabelType& label);
      virtual void reportFailure(const LabelType& label, const StringType& failure);
      virtual void reportSuccess(const LabelType& label, const StringType& success);
      virtual void reportSummary(unsigned long totalTestCount, unsigned long failureCount, double secondsElapsed);

      typedef std::map<const LabelType*,StringType> ResultMapType;
      ResultMapType _success;
      ResultMapType _failure;

      std::vector<const LabelType*> _labels;

    private:
      TestTestReporter(TestTestReporter const&); //purposely not implemented
      TestTestReporter& operator =(TestTestReporter const&); //purposely not implemented
    };

}
}
#endif
