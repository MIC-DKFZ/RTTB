// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTesterMock.h"

#include <assert.h>

namespace lit 
{
namespace testing 
{

    StringType
      TesterMock::
      getTestDescription(void) const
    {
      return "desc";
    };

    StringType
      TesterMock::
      getTestName(void) const
    {
      OStringStream stream;
      stream << "Mock";

      return stream.str();
    };

    TesterMock::
      TesterMock() : _handleSuccessCalls(0), _handleFailureCalls(0), _checkSuccess(false)
    {
    };

    TesterMock::
      ~TesterMock()
    {
    };

    bool
      TesterMock::
      doCheck(void) const
    {
      return _checkSuccess;
    };

    void
      TesterMock::
      handleSuccess(void) const
    {
      ++_handleSuccessCalls;
    };

    void
      TesterMock::
      handleFailure(void) const
    {
      ++_handleFailureCalls;
    };

}
}
