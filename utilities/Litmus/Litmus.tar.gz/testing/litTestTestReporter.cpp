// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestTestReporter.h"
#include <iostream>

namespace lit {
namespace testing {

      TestTestReporter::
      ~TestTestReporter()
    {
    };

      TestTestReporter::
      TestTestReporter()
    {
    };

    void
      TestTestReporter::
      reportComment(const StringType& comment)
    {
    };


    void
      TestTestReporter::
      reportTestStart(const LabelType& label)
    {
      _labels.push_back(&label);
    };

    void
      TestTestReporter::
      reportFailure(const LabelType& label, const StringType& failure)
    {
      _failure.insert(ResultMapType::value_type(&label,failure));
    };

    void
      TestTestReporter::
      reportSuccess(const LabelType& label, const StringType& success)
    {
      _success.insert(ResultMapType::value_type(&label,success));
    };

    void
      TestTestReporter::
      reportSummary(unsigned long totalTestCount, unsigned long failureCount, double secondsElapsed)
    {
    };

}
}