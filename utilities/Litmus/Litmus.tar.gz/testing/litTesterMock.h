// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TESTER_MOCK_H
#define __LIT_TESTER_MOCK_H

#include "litTesterBase.h"

namespace lit {
namespace testing {

    /*! @brief MockObject of a Tester
    * @ingroup Tester*/
    class TesterMock: public TesterBase
    {
    public:
      typedef TesterMock Self;
      typedef TesterBase Superclass;

      virtual StringType getTestDescription(void) const;
      virtual StringType getTestName(void) const;

      TesterMock();
      virtual ~TesterMock();

      mutable int _handleSuccessCalls;
      mutable int _handleFailureCalls;
      bool _checkSuccess;

    protected:
      /*! performes the test and checks the results.
      * @result Indicates if the test was successfull (true) or if it failed (false)
      */
      virtual bool doCheck(void) const;

      /*! Function will be called be check() if test was succesfull.
      * Implement to realize special tester behaviour.
      */
      virtual void handleSuccess(void) const;

      /*! Function will be called be check() if test was a failure.
      * Implement to realize special tester behaviour.
      */
      virtual void handleFailure(void) const;

    private:
      TesterMock(Self& source); //purposely not implemented
      void operator=(const Self&); //purposely not implemented
    };

}
}

#endif
