// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4432 $ (last changed revision)
// @date    $Date: 2013-01-22 14:30:04 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/

#if defined(_MSC_VER)
#pragma warning ( disable : 4786 )
#endif

#include "litChecks.h"
#include "litCheckMacros.h"
#include "litTestResults.h"
#include "litTestReporter.h"
#include "litStdCOutTestReporter.h"
#include "litDefaultTestReporting.h"
#include "litTestLabel.h"
#include "litTestLocation.h"
#include "litTesterBase.h"
#include "litTextFileTester.h"
#include "litValueRecorder.h"

int main ( int , char**  )
{
  
  return EXIT_SUCCESS;
}

