// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestResults.h"
#include "litTestTestReporter.h"
#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  lit::TestResults result1;
  lit::testing::TestTestReporter reporter;
  lit::TestResults result2(&reporter);

  lit::TestLabel label1("l1","test.cpp",42);
  lit::TestLabel label2("l2","test.cpp",43);
  lit::TestLabel label3("l3","test.cpp",44);

  if (result1.getReporter()!=0)
  {
    std::cout << "Error! Reporter is not null." << std::endl;
    return EXIT_FAILURE;
  }

  if (result2.getReporter()!=&reporter)
  {
    std::cout << "Error! Reporter is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  if (result1.getTotalTestCount()!=0)
  {
    std::cout << "Error! getTotalTestCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }
  if (result1.getFailureCount()!=0)
  {
    std::cout << "Error! getFailureCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }
  if (result1.getSuccessCount()!=0)
  {
    std::cout << "Error! getSuccessCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  result1.onTestStart(label1);
  result1.onTestFailure(label1,"false");
  result1.onTestStart(label2);
  result1.onTestSuccess(label2, "OK");
  result1.onTestStart(label3);
  result1.onTestSuccess(label3, "OK2");

  if (result1.getTotalTestCount()!=3)
  {
    std::cout << "Error! getTotalTestCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }
  if (result1.getFailureCount()!=1)
  {
    std::cout << "Error! getFailureCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }
  if (result1.getSuccessCount()!=2)
  {
    std::cout << "Error! getSuccessCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  result2.onTestStart(label1);
  result2.onTestFailure(label1,"false");
  result2.onTestStart(label2);
  result2.onTestSuccess(label2, "OK");
  result2.onTestStart(label3);
  result2.onTestSuccess(label3, "OK2");

  if (result2.getFailureCount()!=1)
  {
    std::cout << "Error! getFailureCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }
  if (result2.getSuccessCount()!=2)
  {
    std::cout << "Error! getSuccessCount is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._labels[0] != &label1)
  {
    std::cout << "Error! onTestStart propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._labels[1] != &label2)
  {
    std::cout << "Error! onTestStart propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._labels[2] != &label3)
  {
    std::cout << "Error! onTestStart propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._success[&label2] != "OK")
  {
    std::cout << "Error! onTestSuccess propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._success[&label3] != "OK2")
  {
    std::cout << "Error! onTestSuccess propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  if (reporter._failure[&label1] != "false")
  {
    std::cout << "Error! onTestFailure propergates incorrect to reporter." << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
