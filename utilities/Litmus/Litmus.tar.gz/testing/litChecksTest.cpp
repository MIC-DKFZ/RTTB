// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litChecks.h"
#include "litString.h"

#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  lit::TestResults results;
  lit::TestLabel label("label","test.cpp",42);

  /***********************************************
   * check
   ***********************************************/
  if (!lit::check<bool>(true))
  {
    std::cout << "Error! check<> is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  if (lit::check<bool>(false))
  {
    std::cout << "Error! check<> is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkEqual<type,type>
   ***********************************************/
  lit::checkEqual<int,int>(results,label,1,0);
  if ((results.getFailureCount()!=1)||(results.getSuccessCount()!=0))
  {
    std::cout << "Error! checkEqual<type,type> is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkEqual<int,int>(results,label,1,1);
  if ((results.getFailureCount()!=1)||(results.getSuccessCount()!=1))
  {
    std::cout << "Error! checkEqual<type,type> is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkEqual (char version)
   ***********************************************/
  lit::checkEqual(results,label,'a','b');
  if ((results.getFailureCount()!=2)||(results.getSuccessCount()!=1))
  {
    std::cout << "Error! checkEqual char version is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkEqual(results,label,'a','a');
  if ((results.getFailureCount()!=2)||(results.getSuccessCount()!=2))
  {
    std::cout << "Error! checkEqual char version is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkEqual (StringType version)
   ***********************************************/
  lit::checkEqual(results,label,lit::StringType("a"),lit::StringType("b"));
  if ((results.getFailureCount()!=3)||(results.getSuccessCount()!=2))
  {
    std::cout << "Error! checkEqual StringType version is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkEqual(results,label,'a','a');
  if ((results.getFailureCount()!=3)||(results.getSuccessCount()!=3))
  {
    std::cout << "Error! checkEqual StringType version is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkClose
   ***********************************************/
  lit::checkClose(results,label,1,0,0);
  if ((results.getFailureCount()!=4)||(results.getSuccessCount()!=3))
  {
    std::cout << "Error! checkClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkClose(results,label,1,1,0);
  if ((results.getFailureCount()!=4)||(results.getSuccessCount()!=4))
  {
    std::cout << "Error! checkClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkClose(results,label,1,0,1);
  if ((results.getFailureCount()!=4)||(results.getSuccessCount()!=5))
  {
    std::cout << "Error! checkClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkClose(results,label,1,0,0.1);
  if ((results.getFailureCount()!=5)||(results.getSuccessCount()!=5))
  {
    std::cout << "Error! checkClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkArrayEqual
   ***********************************************/
  double a1[5];
  double a2[5];
  double a3[5];

  for (int i = 0; i<5; ++i)
  {
    a1[i] = i;
    a2[i] = i;
    a3[i] = i;
  }

  a3[2] = 2.2;

  lit::checkArrayEqual(results,label,a1,a2,5);
  if ((results.getFailureCount()!=5)||(results.getSuccessCount()!=6))
  {
    std::cout << "Error! checkArrayEqual is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkArrayEqual(results,label,a1,a3,5);
  if ((results.getFailureCount()!=6)||(results.getSuccessCount()!=6))
  {
    std::cout << "Error! checkArrayEqual is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * ArrayAreClose
   ***********************************************/
  if (lit::ArrayAreClose(a1,a3,5,0.0))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  if (!lit::ArrayAreClose(a1,a2,5,0.0))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  if (!lit::ArrayAreClose(a1,a3,5,0.2))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  if (lit::ArrayAreClose(a1,a3,5,0.1))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  if (!lit::ArrayAreClose(a1,a3,5,1))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * checkArrayClose
   ***********************************************/
  lit::checkArrayClose(results,label,a1,a3,5,0.0);
  if ((results.getFailureCount()!=7)||(results.getSuccessCount()!=6))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkArrayClose(results,label,a1,a3,5,0.2);
  if ((results.getFailureCount()!=7)||(results.getSuccessCount()!=7))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  lit::checkArrayClose(results,label,a1,a2,5,0.0);
  if ((results.getFailureCount()!=7)||(results.getSuccessCount()!=8))
  {
    std::cout << "Error! ArrayAreClose is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
