// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestLocation.h"
#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  lit::TestLocation location1("test.cpp",42);

  if ((location1.getFile() != "test.cpp") || (location1.getLine()!=42))
  {
    std::cout << "Error! Constructor location1(\"test.cpp\",42) generates illegal location: " << location1 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLocation location2(location1);

  if ((location2.getFile() != "test.cpp") || (location2.getLine()!=42))
  {
    std::cout << "Error! Constructor location2(\"test.cpp\",42) generates illegal location: " << location2 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLocation location3("test.cpp",43);
  lit::TestLocation location4("test2.cpp",43);
  lit::TestLocation location5("test2.cpp",42);

  if (!(location1 == location2))
  {
    std::cout << "Error! Comparison of labels is incorrect (location1 == location2 -> false)" << std::endl;
    return EXIT_FAILURE;
  }
  if (location1 == location3)
  {
    std::cout << "Error! Comparison of labels is incorrect (location1 == location3 -> true)" << std::endl;
    return EXIT_FAILURE;
  }
  if (location1 == location4)
  {
    std::cout << "Error! Comparison of labels is incorrect (location1 == location4 -> true)" << std::endl;
    return EXIT_FAILURE;
  }
  if (location1 == location5)
  {
    std::cout << "Error! Comparison of labels is incorrect (location1 == location5 -> true)" << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLocation location6 = location1;

  if ((location6.getFile() != "test.cpp") || (location6.getLine()!=42))
  {
    std::cout << "Error! Assignment operator is incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  if (location1.toStr() != "test.cpp(42)")
  {
    std::cout << "Error! toStr() is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
