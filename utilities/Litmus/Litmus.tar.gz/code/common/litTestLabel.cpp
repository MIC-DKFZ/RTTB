// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestLabel.h"

namespace lit {

    StringType TestLabel::_defaultName = "unnamed test";

    TestLabel::
      TestLabel(const StringType& name, const StringType& file, int line)
      : _name(name),_file(file),_line(line)
    {
    };

    TestLabel::
      TestLabel(const StringType& name, const TestLocation& location)
      : _name(name)
    {
      _file = location.getFile();
      _line = location.getLine();
    };

    TestLabel::
      TestLabel(const TestLocation& location)
      : _name(_defaultName)
    {
      _file = location.getFile();
      _line = location.getLine();
    };

    TestLabel::
      TestLabel(const StringType& file, int line)
      : _name(_defaultName),_file(file),_line(line)
    {
    };

    TestLabel::
      TestLabel(const TestLabel& source)
    {
      _name=source._name;
      _file=source._file;
      _line=source._line;
    };


    TestLabel&
      TestLabel::
      operator =(const TestLabel& rhs)
    { //spared self assignement check, because ist happens seldom
      //has no negativ effect in this case; so save the check cost
      _name=rhs._name;
      _file=rhs._file;
      _line=rhs._line;
      return *this;
    };

    bool 
      TestLabel::
      operator ==(const TestLabel& rhs) const
    {
      //the sequence of comparison is ordered by the entropies of the attributes
      //so _line may differ most often.
      if (_line!=rhs._line) return false;
      if (_file!=rhs._file) return false;
      if (_name!=rhs._name) return false;

      return true;
    };

    StringType
      TestLabel::
      getName() const
    {
      return _name;
    };

    StringType
      TestLabel::
      getFile() const
    {
      return _file;
    };

    int
      TestLabel::
      getLine() const
    {
      return _line;
    };

    StringType
      TestLabel::
      toStr() const
    {
      OStringStream stream;
      stream << _file<<"("<<_line<<") : "<<_name;
      return stream.str();
    };

    void
      TestLabel::
      setDefaultName(const StringType& name)
    {
      _defaultName = name;
    };

    std::ostream &
      operator<<(std::ostream &os, const TestLabel &label)
    {
      os << label.toStr();
      return os;
    };


}
