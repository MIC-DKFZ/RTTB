// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_LOCATION_H
#define __LIT_TEST_LOCATION_H

#include "litString.h"

namespace lit {
    /*! @brief TestLocation indicates a test location within a file.
     * It is used by the Testing fascility to indicate test location
     * and therefor identify special tests.
     * @sa TestLabel
     * @ingroup Testing*/
    class LitmusCommon_EXPORT TestLocation
    {
    public:

      TestLocation(const StringType& file, int line);
      TestLocation(const TestLocation& source);
      TestLocation& operator =(const TestLocation& rhs);
      bool operator ==(const TestLocation& rhs) const;

	    StringType getFile() const;
	    int getLine() const;
	    StringType toStr() const;

  	protected:
      StringType _file;
      int _line;
    };

    LitmusCommon_EXPORT std::ostream & operator<<(std::ostream &os, const TestLocation &location);
}

#endif
