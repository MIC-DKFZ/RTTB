// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litStdCOutTestReporter.h"
#include <iostream>

namespace lit {

      StdCOutTestReporter::
      ~StdCOutTestReporter()
    {
    };

      StdCOutTestReporter::
      StdCOutTestReporter()
    {
    };

    void
      StdCOutTestReporter::
      reportComment(const StringType& comment)
    {
      std::cout  << "Test start: "<<comment<<std::endl;
    };


    void
      StdCOutTestReporter::
      reportTestStart(const LabelType& label)
    {
      std::cout  << "Test start: "<<label<<std::endl;
    };

    void
      StdCOutTestReporter::
      reportFailure(const LabelType& label, const StringType& failure)
    {
      std::cout << "Test failed." << std::endl << failure << std::endl<<std::endl;
    };

    void
      StdCOutTestReporter::
      reportSuccess(const LabelType& label, const StringType& success)
    {
      std::cout << "Test passed." << std::endl << success << std::endl<<std::endl;
    };

    void
      StdCOutTestReporter::
      reportSummary(unsigned long totalTestCount, unsigned long failureCount, double secondsElapsed)
    {
      std::cout << "Test summary: "<< std::endl;
      if (failureCount>0)
      {
        std::cout << "FAILURE: "<<failureCount<<" out of "<<totalTestCount<<" failed"<<std::endl;
      }
      else
      {
        std::cout << "Success: "<<totalTestCount<<" passed"<<std::endl;
      }
      std::cout << "Test time: "<<secondsElapsed<<" seconds"<<std::endl;
    };

}
