// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_LABEL_H
#define __LIT_TEST_LABEL_H

#include "litTestLocation.h"

namespace lit {

  /*! @brief TestLabel is used to identify a test.
  * A test in a test set is labeled by a name and its location.
  * @sa TestLocation
  * @ingroup Testing*/
  class LitmusCommon_EXPORT TestLabel
  {
  public:

    TestLabel(const StringType& name, const StringType& file, int line);
    TestLabel(const StringType& name, const TestLocation& location);
    TestLabel(const StringType& file, int line);
    TestLabel(const TestLocation& location);
    TestLabel(const TestLabel& source);
    TestLabel& operator =(const TestLabel& rhs);
    bool operator ==(const TestLabel& rhs) const;

    StringType getName() const;
    StringType getFile() const;
    int getLine() const;
    StringType toStr() const;

    static void setDefaultName(const StringType& name);

  protected:
    StringType _name;
    StringType _file;
    int _line;
    static StringType _defaultName;
  };

  LitmusCommon_EXPORT std::ostream & operator<<(std::ostream &os, const TestLabel &label);

}

#endif
