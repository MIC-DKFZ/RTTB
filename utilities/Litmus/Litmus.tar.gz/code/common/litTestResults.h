// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_RESULTS_H
#define __LIT_TEST_RESULTS_H

#include "litTestLabel.h"

#include <time.h>
#include <map>

namespace lit {

    class TestReporter;

    /*! @brief Class used to aggregate and report the test results
     * @ingroup Testing*/
    class LitmusCommon_EXPORT TestResults
    {
    public:
      explicit TestResults(TestReporter* reporter = 0);

	    typedef TestLabel LabelType;

      void onTestStart(const LabelType& label);
      void onTestFailure(const LabelType& label, const StringType& failure);
      void onTestSuccess(const LabelType& label, const StringType& success);

      void reportSummary() const;

      unsigned long getTotalTestCount() const;
      unsigned long getFailureCount() const;
      unsigned long getSuccessCount() const;

      TestReporter* getReporter() const;

    private:
      /*! Just the pointer to testreporter.
      * TestResults doesn't manage the instance, it assumes that
      * the developer is managed by the user.*/
      mutable TestReporter* _pTestReporter;

      unsigned long _totalTestCount;
      unsigned long _failureCount;
      unsigned long _successCount;
      clock_t _firstTestStart;
      clock_t _latestTestStop;

      TestResults(TestResults const&); //purposely not implemented
      TestResults& operator =(TestResults const&); //purposely not implemented
    };

}

#endif
