// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_CHECK_MACROS_H
#define __LIT_CHECK_MACROS_H


#include "litChecks.h"
#include "litTestLabel.h"
#include "litDefaultTestReporting.h"

#include <stdlib.h>

#ifdef CHECK
    #error "Litmus redefines CHECK"
#endif


/*! @brief Generates a local TestResults variable as referene to ::lit::getTestResults().
 @ingroup Testing*/
#define PREPARE_DEFAULT_TEST_REPORTING \
    ::lit::TestResults& testResults = ::lit::getTestResults();\
    ::lit::TestLabel litLastTestLabel("Test start",__FILE__,__LINE__)

/*! @brief Evalutes the variable testResults
 * Evalutes the variable testResults, generates the test summery and exits the function by returning
 * the overall success.
 @ingroup Testing*/
#define RETURN_AND_REPORT_TEST_SUCCESS \
    testResults.reportSummary();\
    return (testResults.getFailureCount() == 0 ? EXIT_SUCCESS : EXIT_FAILURE)

/*! @brief Sets up a test that checks if the passed statement can be evaluated to true.
 @ingroup Testing*/
#define CHECK(value) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check value: " <<#value; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        try { \
          testResults.onTestStart(litLastTestLabel);\
          if (!::lit::check(value)) \
          {\
          testResults.onTestFailure( litLastTestLabel, #value); \
          }\
          else\
          {\
            testResults.onTestSuccess( litLastTestLabel, #value); \
          }\
        } \
        catch (...) { \
            testResults.onTestFailure(litLastTestLabel, \
                    "Unhandled exception in CHECK(" #value ")"); \
        } \
    } while (0)

/*! @brief Sets up a test that checks if the passed values are equal.
 @ingroup Testing*/
#define CHECK_EQUAL(expected, actual) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check equal: " <<#expected<<" == "<<#actual; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        try { \
        ::lit::checkEqual(testResults, litLastTestLabel, expected, actual); \
        } \
        catch (...) { \
            testResults.onTestFailure(litLastTestLabel, \
                    "Unhandled exception in CHECK_EQUAL(" #expected ", " #actual ")"); \
        } \
    } while (0)

/*! @brief Sets up a test that checks if the passed values are close.
 @ingroup Testing*/
#define CHECK_CLOSE(expected, actual, tolerance) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check close: " <<#expected<<" == "<<#actual << " (+- " << #tolerance<<")" ; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        try { \
        ::lit::checkClose(testResults, litLastTestLabel, expected, actual, tolerance); \
        } \
        catch (...) { \
            testResults.onTestFailure(litLastTestLabel, \
                    "Unhandled exception in CHECK_CLOSE(" #expected ", " #actual ")"); \
        } \
    } while (0)

/*! @brief Sets up a test that checks if the values of the passed arrays are equal.
 @ingroup Testing*/
#define CHECK_ARRAY_EQUAL(expected, actual, count) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check array equal: " <<#expected<<" == "<<#actual << "; count: " << #count ; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        try { \
            ::lit::checkArrayEqual(testResults, litLastTestLabel, expected, actual, count); \
        } \
        catch (...) { \
            testResults.onTestFailure(litLastTestLabel, \
                    "Unhandled exception in CHECK_ARRAY_EQUAL(" #expected ", " #actual ")"); \
        } \
    } while (0)

/*! @brief Sets up a test that checks if the values of the passed arrays are close.
 @ingroup Testing*/
#define CHECK_ARRAY_CLOSE(expected, actual, count, tolerance) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check array close: " <<#expected<<" == "<<#actual << " (+- " << #tolerance << "); count: " << #count ; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        try { \
            ::lit::checkArrayClose(testResults, litLastTestLabel, expected, actual, count, tolerance); \
        } \
        catch (...) { \
            testResults.onTestFailure(litLastTestLabel, \
                    "Unhandled exception in CHECK_ARRAY_CLOSE(" #expected ", " #actual ")"); \
        } \
    } while (0)

/*! @brief Sets up a test that checks if the expression throws a special exception.
 * Test awaits a thrown exception to be passed successfully.
 @ingroup Testing*/
#define CHECK_THROW_EXPLICIT(expression, ExpectedExceptionType) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check throw: " <<#expression<<" throws "<<#ExpectedExceptionType; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        testResults.onTestStart(litLastTestLabel);\
        bool caught_ = false; \
        try { expression; } \
        catch (ExpectedExceptionType const&) { caught_ = true; } \
        catch (...) {} \
        if (!caught_) \
        {\
          testResults.onTestFailure(litLastTestLabel, "Expected exception \"" #ExpectedExceptionType "\" was not thrown"); \
        }\
        else\
        {\
          testResults.onTestSuccess(litLastTestLabel, "Expected exception \"" #ExpectedExceptionType "\" was thrown"); \
        }\
    } while(0)

/*! @brief Sets up a test that checks if the expression throws any exception.
 * Test awaits a thrown exception to be passed successfully.
 @ingroup Testing*/
#define CHECK_THROW(expression) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check throw: " <<#expression<<" throws an exception"; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        testResults.onTestStart(litLastTestLabel);\
        bool caught_ = false; \
        try { expression; } \
        catch (...) { caught_ = true; } \
        if (!caught_) \
        {\
          testResults.onTestFailure(litLastTestLabel, "No exception was thrown"); \
        }\
        else\
        {\
          testResults.onTestSuccess(litLastTestLabel, "An exception was thrown"); \
        }\
    } while(0)

/*! @brief Sets up a test that checks if the expression doesn't throw a special exception.
 * Test is successful if the exception has not been thrown.
 @ingroup Testing*/
#define CHECK_NO_THROW_EXPLICIT(expression, UnwantedExceptionType) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check throw: " <<#expression<<" doesn't throw "<<#UnwantedExceptionType; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        testResults.onTestStart(litLastTestLabel);\
        bool caught_ = false; \
        try { expression; } \
        catch (UnwantedExceptionType const&) { caught_ = true; } \
        catch (...) {} \
        if (caught_) \
        {\
          testResults.onTestFailure(litLastTestLabel, "Unwanted exception \"" #UnwantedExceptionType "\" was thrown"); \
        }\
        else\
        {\
          testResults.onTestSuccess(litLastTestLabel, "Unwanted exception \"" #UnwantedExceptionType "\" was not thrown"); \
        }\
    } while(0)

/*! @brief Sets up a test that checks if the expression doesn't throw any exception.
 * Test is successful if no exception has been thrown.
 @ingroup Testing*/
#define CHECK_NO_THROW(expression) \
    do \
    { \
        ::lit::OStringStream stream; \
        stream << "Check throw: " <<#expression<<" no throw guarantee"; \
        litLastTestLabel = ::lit::TestLabel(stream.str(),__FILE__,__LINE__);\
        testResults.onTestStart(litLastTestLabel);\
        bool caught_ = false; \
        try { expression; } \
        catch (...) { caught_ = true; } \
        if (caught_) \
        {\
          testResults.onTestFailure(litLastTestLabel, "An unwanted exception was thrown"); \
        }\
        else\
        {\
          testResults.onTestSuccess(litLastTestLabel, "No exception was thrown"); \
        }\
    } while(0)

/*! @brief Sets up a test that uses a tester.
 * Test is successful if the tester is evaluated successfull.
 @ingroup Testing*/
#define CHECK_TESTER(tester) \
    do \
    { \
        ::lit::TestLocation testLocation(__FILE__,__LINE__);\
        try { \
        tester.check(testResults, testLocation); \
        } \
        catch (...) { \
            testResults.onTestFailure(tester.getCurrentTestLabel(), \
                    "Unhandled exception in CHECK_TESTER(" #tester ")"); \
        } \
    } while (0)
#endif
