// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTesterBase.h"

#include <assert.h>

namespace lit 
{

  bool
    TesterBase::
    getInvertCheck() const
  {
    return _invertCheck;
  };
  void 
    TesterBase::
    setInvertCheck(bool invert)
  {
    _invertCheck = invert;
  };
  void 
    TesterBase::
    invertCheckOn()
  {
    _invertCheck = true;
  };
  void 
    TesterBase::
    invertCheckOff()
  {
    _invertCheck = false;
  };

  void 
    TesterBase::
    check(TestResults& results, const TestLocation& location) const
  {
    _pResults = &results;
    _label = TestLabel(this->getTestName(),location);

    bool checkResult = doCheck();
    if (_invertCheck)
    {
      checkResult = !checkResult;
    }

    if (checkResult)
    {
      handleSuccess();
    }
    else
    {
      handleFailure();
    }
  };

  TestLabel&
    TesterBase::
    getCurrentTestLabel(void) const
  {
    return _label;
  };

  TestResults&
    TesterBase::
    getCurrentTestResult(void) const
  {
    assert(_pResults); //must be set by check; call check first
    return *_pResults;
  };

  TesterBase::
    TesterBase(): _label("",0), _invertCheck(false)
  {
    _pResults = 0;
  };

  TesterBase::
    ~TesterBase()
  {
  };


}