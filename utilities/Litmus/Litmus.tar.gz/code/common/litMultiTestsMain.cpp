// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4432 $ (last changed revision)
// @date    $Date: 2013-01-22 14:30:04 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
//
// This file is used to create TestDriver executables
// These executables are able to register a function pointer to a string name
// in a lookup table.   By including this file, it creates a main function
// that calls RegisterTests() then looks up the function pointer for the test
// specified on the command line.
*/


#include "litMultiTestsMain.h"
#include "litDefaultTestReporting.h"
#include "litString.h"
#include <map>
#include <iostream>

namespace lit
{
  std::map<StringType, MainFuncPointer> _stringToTestFunctionMap;

  void registerTest(const StringType& testName, MainFuncPointer testFuncPtr)
  {
    _stringToTestFunctionMap[testName] = testFuncPtr;
  };

  void printAvailableTests()
  {
    std::cout << "Available tests:\n";
    std::map<StringType, MainFuncPointer>::iterator j = _stringToTestFunctionMap.begin();
    int i = 0;
    while(j != _stringToTestFunctionMap.end())
    {
      std::cout << i << ". " << j->first << "\n";
      ++i;
      ++j;
    }
  }

  int multiTestsMain(int ac, char* av[] )
  {
    int result = 0;
    StringType testToRun;

    if(ac < 2)
    {
      printAvailableTests();
      std::cout << "To run a test, enter the test number: ";
      int testNum = 0;
      std::cin >> testNum;
      std::map<StringType, lit::MainFuncPointer>::iterator j = lit::_stringToTestFunctionMap.begin();
      int i = 0;
      while(j != lit::_stringToTestFunctionMap.end() && i < testNum)
      {
        ++i;
        ++j;
      }
      if(j == lit::_stringToTestFunctionMap.end())
      {
        std::cerr << testNum << " is an invalid test number\n";
        return -1;
      }
      testToRun = j->first;
    }
    else
    {
      testToRun = av[1];
    }

    std::map<StringType, lit::MainFuncPointer>::iterator j = lit::_stringToTestFunctionMap.find(testToRun);
    if(j != lit::_stringToTestFunctionMap.end())
    {
      lit::MainFuncPointer f = j->second;

      // Invoke the test's "main" function.
      result = (*f)(ac-1, av+1);
    }
    else
    {
      lit::printAvailableTests();
      std::cerr << "Failed: " << testToRun << ": No test registered with name " << testToRun << "\n";
      result = -1;
    }
    return result;
  }

} //namespace lit
