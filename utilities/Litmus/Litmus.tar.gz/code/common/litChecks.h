// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_CHECKS_H
#define __LIT_CHECKS_H

#include "litTestResults.h"
#include "litTestLabel.h"

namespace lit {

    /*! @brief Checks if the passed value is true or false.
     @ingroup Testing*/
    template< typename Value >
    bool check(Value const value)
    {
      return !!value; // doing double negative to avoid VS warnings
    }

    /*! @brief Checks two passed values for equality and commits the result to the TestResults.
     @ingroup Testing*/
    template< typename TExpected, typename TActual >
    void checkEqual(TestResults& results, const TestLabel& label, TExpected const expected, TActual const actual)
    {
      results.onTestStart(label);
      if (!(expected == actual))
      {
        OStringStream stream;
        stream << "Expected " << expected << " but was " << actual;
        results.onTestFailure(label, stream.str());
      }
      else
      {
        OStringStream stream;
        stream << expected << " equals " << actual;
        results.onTestSuccess(label, stream.str());
      }
    }

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, char const* expected, char const* actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, char* expected, char* actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, char* expected, char const* actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, char const* expected, char* actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, const StringType& expected, const StringType& actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, char const* expected, const StringType& actual);

    LitmusCommon_EXPORT void checkEqual(TestResults& results, const TestLabel& label, const StringType& expected, char const* actual);


    template< typename Expected, typename Actual, typename Tolerance >
    bool AreClose(Expected const expected, Actual const actual, Tolerance const tolerance)
    {
      return (actual >= (expected - tolerance)) && (actual <= (expected + tolerance));
    }

    /*! @brief Checks if two passed values are close equality and commits the result to the TestResults.
     @ingroup Testing*/
    template< typename Expected, typename Actual, typename Tolerance >
    void checkClose(TestResults& results, const TestLabel& label, Expected const expected, Actual const actual, Tolerance const tolerance)
    {
      results.onTestStart(label);
      if (!AreClose(expected, actual, tolerance))
      {
        OStringStream stream;
        stream << "Expected " << expected << " +/- " << tolerance << " but was " << actual;
        results.onTestFailure(label, stream.str());
      }
      else
      {
        OStringStream stream;
        stream << expected << " +/- " << tolerance << " equals " << actual;
        results.onTestSuccess(label, stream.str());
      }
    }


    /*! @brief Checks if the values of two passed arrays are equal and commits the result to the TestResults.
     @ingroup Testing*/
    template< typename Expected, typename Actual >
    void checkArrayEqual(TestResults& results, const TestLabel& label, Expected const expected, Actual const actual,
      int const count)
    {
      results.onTestStart(label);

      bool equal = true;
      for (int i = 0; i < count; ++i)
        equal &= (expected[i] == actual[i]);

      if (!equal)
      {
        OStringStream stream;
        stream << "Expected [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << expected[i] << " ";
        }
        stream << "] but was [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << actual[i] << " ";
        }
        stream << "]";
        results.onTestFailure(label, stream.str());
      }
      else
      {
        OStringStream stream;
        stream << "Expected [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << expected[i] << " ";
        }
        stream << "] equals [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << actual[i] << " ";
        }
        stream << "]";
        results.onTestSuccess(label, stream.str());
      }
    }

    template< typename Expected, typename Actual, typename Tolerance >
    bool ArrayAreClose(Expected const expected, Actual const actual, int const count, Tolerance const tolerance)
    {
      bool equal = true;
      for (int i = 0; i < count; ++i)
        equal &= AreClose(expected[i], actual[i], tolerance);
      return equal;
    }

    /*! @brief Checks if the values of two passed arrays are close and commits the result to the TestResults.
     @ingroup Testing*/
    template< typename Expected, typename Actual, typename Tolerance >
    void checkArrayClose(TestResults& results, const TestLabel& label, Expected const expected, Actual const actual,
      int const count, Tolerance const tolerance)
    {
      results.onTestStart(label);
      bool equal = ArrayAreClose(expected, actual, count, tolerance);

      if (!equal)
      {
        OStringStream stream;
        stream << "Expected [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << expected[i] << " ";
        }
        stream << "] +/- " << tolerance << " but was [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << actual[i] << " ";
        }
        stream << "]";

        results.onTestFailure(label, stream.str());
      }
      else
      {
        OStringStream stream;
        stream << "Expected [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << expected[i] << " ";
        }
        stream << "] +/- " << tolerance << " equals [ ";
        for (int i = 0; i < count; ++i)
        {
          stream << actual[i] << " ";
        }
        stream << "]";

        results.onTestSuccess(label, stream.str());
      }
    }

}

#endif
