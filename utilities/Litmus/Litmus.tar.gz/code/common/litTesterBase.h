// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TESTER_BASE_H
#define __LIT_TESTER_BASE_H

#include "litTestResults.h"
#include "litTestLabel.h"

namespace lit {
    
    /*! @brief Base class for testers
     * Tester are used in the Litmus testing system and can be seen as
     * functors alowing to define any test criteria as an derivered tester.
     * Testers will handle the result evaluation for their test and any further
     * output to the TestReporter (requested from TestResults)
     * @ingroup Tester*/
    class LitmusCommon_EXPORT TesterBase
    {
    public:
      
      /*! Perform the test, check the test criteria and report the test results.
       * @param results Reference to the TestResults that should be used while checking
       * @param location Location of the test (used to generate a proper lable.
       * */
      void check(TestResults& results, const TestLocation& location) const;

      /*! Returns a string that specifies the test the tester currently performs.
       */
      virtual StringType getTestDescription(void) const = 0;
      virtual StringType getTestName(void) const = 0;

      TestLabel& getCurrentTestLabel(void) const;
      TestResults& getCurrentTestResult(void) const;

      bool getInvertCheck() const;
      void setInvertCheck(bool invert);
      void invertCheckOn();
      void invertCheckOff();

    protected:
      TesterBase();
      virtual ~TesterBase();

      /*! performes the test and checks the results.
       * @result Indicates if the test was successfull (true) or if it failed (false)
       */
      virtual bool doCheck(void) const = 0;

      /*! Function will be called be check() if test was succesfull.
       * Implement to realize special tester behaviour.
       */
      virtual void handleSuccess(void) const = 0;

      /*! Function will be called be check() if test was a failure.
       * Implement to realize special tester behaviour.
       */
      virtual void handleFailure(void) const = 0;

      mutable TestResults* _pResults;
      mutable TestLabel _label;

      /*!Indicates if check result should be inverted. Thus it is like a logical not for the check.*/
      bool _invertCheck;
    private:
      TesterBase(TesterBase& source); //purposely not implemented
      void operator=(const TesterBase&); //purposely not implemented
    };

}

#endif
