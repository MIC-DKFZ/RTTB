// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_IMAGE_IO_H
#define __LIT_TEST_IMAGE_IO_H

#include "litString.h"

#include "itkMacro.h"
#include "itkImage.h"

namespace lit {

    /*! 
     * Class offering IO functionality for loading and writing test images with any output pixel type.
     * Image will be converted to the internal image type when loaded.
     * @ingroup Testing*/
    template <typename TExternalPixelType, typename TInternalImageType>
    class TestImageIO
    {
    public:
      typedef TInternalImageType InternalImageType;
      typedef typename InternalImageType::Pointer InternalImagePointer;
      typedef itk::Image<TExternalPixelType, InternalImageType::ImageDimension> ExternalImageType;

      static InternalImagePointer readImage(const StringType& fileName);
      static void writeImage(const InternalImageType* pImage, const StringType& fileName);

  	protected:
      TestImageIO(); //purposely not implemented
      ~TestImageIO(); //purposely not implemented
      TestImageIO(const TestImageIO&); //purposely not implemented
      TestImageIO& operator = (const TestImageIO&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
#include "litTestImageIO.tpp"
#endif

#endif
