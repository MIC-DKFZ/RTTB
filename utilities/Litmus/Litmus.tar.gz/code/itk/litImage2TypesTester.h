// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_IMAGE_2TYPES_TESTER_H
#define __LIT_IMAGE_2TYPES_TESTER_H

#include "litTesterBase.h"

namespace lit {

    /*! @brief Tester that compares two images
    * @ingroup Tester*/
    template<class TImage, class TTestImages>
    class Image2TypesTester: public TesterBase
    {
    public:
      typedef Image2TypesTester<TImage, TTestImages> Self;
      typedef TesterBase Superclass;
      typedef TImage ImageType;
      typedef TTestImages TestImageType;
      typedef typename ImageType::Pointer ImagePointer;
      typedef typename ImageType::ConstPointer ExpectedImageConstPointer;
      typedef typename TestImageType::ConstPointer ActualImageConstPointer;

      virtual StringType getTestDescription(void) const;
      virtual StringType getTestName(void) const;

      void setExpectedImage(const ImageType* pImage);
      void setActualImage(const TestImageType* pImage);
      void setCheckThreshold(double checkThreshold);

      const ImageType* getExpectedImage() const;
      const TestImageType* getActualImage() const;
      double getCheckThreshold() const;

      void setTestFileName(const StringType& testFileName);
      const StringType& getTestFileName() const;

      void setSaveTestFiles(bool saveFiles);
      bool getSaveTestFiles() const;

      void setCheckImageGeometry(bool checkGeometry);
      bool getCheckImageGeometry() const;

      Image2TypesTester();
      virtual ~Image2TypesTester();

    protected:
      ExpectedImageConstPointer _spExpectedImage;
      ActualImageConstPointer _spActualImage;
      double _checkThreshold;
      StringType _testFileName;
      bool _saveTestFiles;
      /** Defines if the tester should only check the image buffer/pixel values (_checkGeometry == false)
       * or also if spacing, orientation and origin of the images match (_checkGeometry == true) */
      bool _checkGeometry;
      mutable unsigned long _errorPixelCount;
      mutable typename TestImageType::PixelType _maxError;
      mutable typename TestImageType::IndexType _maxErrorIndex;

      /*! performs the test and checks the results.
      * @result Indicates if the test was successful (true) or if it failed (false)
      */
      virtual bool doCheck(void) const;

      /*! Function will be called be check() if test was succesfull.
      * Implement to realize special tester behavior.
      */
      virtual void handleSuccess(void) const;

      /*! Function will be called be check() if test was a failure.
      * Implement to realize special tester behavior.
      */
      virtual void handleFailure(void) const;

      void saveTestFiles(OStringStream& stream) const;

    private:
      Image2TypesTester(Self& source); //purposely not implemented
      void operator=(const Self&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
# include "litImage2TypesTester.tpp"
#endif

#endif
