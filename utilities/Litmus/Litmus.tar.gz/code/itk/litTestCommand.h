// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TEST_COMMAND_H
#define __LIT_TEST_COMMAND_H

#include "itkCommand.h"
#include "litConfigure.h"

namespace lit {

  /*! \class TestCommand
  *  \brief TestCommand is used to test for occurance of events
  * This class uses a static variable (_currentCallOrder) to track the occurance of events.
  * Each time execution is called _currentCallOrder is increased and a copy of the value is stored locally (_lastCallOrder).
  * This allows to determine the sequence of the latest execution calls of all test commands.
  * \ingroup Testing
  */
  class LitmusITK_EXPORT TestCommand : public itk::Command
  { 
  public:
    /** Standard class typedefs. */
    typedef TestCommand   Self;
    typedef itk::SmartPointer<Self>    Pointer;

    /** Run-time type information (and related methods). */
    itkTypeMacro(TestCommand,Command);

    /** Method for creation through the object factory. */
    itkNewMacro(Self);

    /** Invoke the callback function. */
    virtual void Execute(::itk::Object * caller,const ::itk::EventObject & e);

    virtual void Execute(const ::itk::Object * caller,const ::itk::EventObject & e);

    unsigned int getEventCount() const;
    void resetEventCount();

    unsigned int getLastCallOrder() const;

    static void resetCallOrder();

  protected:
    virtual void checkEvent(const ::itk::Object * caller,const ::itk::EventObject & e);

    unsigned int _eventCount;
    unsigned int _lastCallOrder;

    static unsigned int _currentCallOrder;

    TestCommand();
    virtual ~TestCommand();

  private:
    TestCommand(const Self&); //purposely not implemented
    void operator=(const Self&); //purposely not implemented
  };

}

#endif
