// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_FIELD_TESTER_H
#define __LIT_FIELD_TESTER_H

#include "litTesterBase.h"

namespace lit {
    
    /*! @brief Tester that compares two vector fields
     * @ingroup Tester*/
    template<class TField>
    class FieldTester: public TesterBase
    {
    public:
      typedef FieldTester<TField> Self;
      typedef TesterBase Superclass;
      typedef TField FieldType;
      typedef typename FieldType::Pointer FieldPointer;

      virtual StringType getTestDescription(void) const;
      virtual StringType getTestName(void) const;

      void setExpectedField(FieldType* pField);
      void setActualField(FieldType* pField);
      void setCheckThreshold(double checkThreshold);

      const FieldType* getExpectedField() const;
      const FieldType* getActualField() const;
      double getCheckThreshold() const;

      void setCheckFieldGeometry(bool checkGeometry);
      bool getCheckFieldGeometry() const;

      FieldTester();
      virtual ~FieldTester();

    protected:
      FieldPointer _spExpectedField;
      FieldPointer _spActualField;
      double _checkThreshold;
      /** Defines if the tester should only check the field buffer/pixel values (_checkGeometry == false)
       * or also if spacing, orientation and origin of the fields match (_checkGeometry == true) */
      bool _checkGeometry;

      mutable unsigned long _errorPixelCount;
      mutable double _maxError;
      mutable typename FieldType::IndexType _maxErrorIndex;

      /*! performes the test and checks the results.
       * @result Indicates if the test was successfull (true) or if it failed (false)
       */
      virtual bool doCheck(void) const;

      /*! Function will be called be check() if test was succesfull.
       * Implement to realize special tester behaviour.
       */
      virtual void handleSuccess(void) const;

      /*! Function will be called be check() if test was a failure.
       * Implement to realize special tester behaviour.
       */
      virtual void handleFailure(void) const;

    private:
      FieldTester(Self& source); //purposely not implemented
      void operator=(const Self&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
# include "litFieldTester.tpp"
#endif

#endif
