// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4432 $ (last changed revision)
// @date    $Date: 2013-01-22 14:30:04 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
//
// This file is used to create TestDriver executables
// These executables are able to register a function pointer to a string name
// in a lookup table.   By including this file, it creates a main function
// that calls RegisterTests() then looks up the function pointer for the test
// specified on the command line.
*/


#include "litConfigure.h"
#include "litString.h"
#include "litMultiTestsMain.h"

namespace lit
{

  /** Difference to multiTestsMain is the fact that it checks for
   * --with-threads [#] or --without-threads flags and passes the
   * thread count to itk::MultiThreader::SetGlobalDefaultNumberOfThreads
   * befor calling multiTestsMain.*/
    int LitmusITK_EXPORT multiTestsMainWithITKThreads(int ac, char* av[]);

} //namespace lit
